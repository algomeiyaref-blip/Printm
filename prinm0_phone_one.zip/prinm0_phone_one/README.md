# prinm0 v2 — Mobile + AI Backend

هذه نسخة المرحلة الثانية:
- تطبيق الواجهة يبقى خفيفاً على الهاتف.
- Backend يعمل 24/7 على استضافة سحابية.
- OpenAI يتم استدعاؤه من الخادم.
- Webhook جاهز لاستقبال أحداث Meta.
- SQLite مبدئياً لتخزين المحادثات.
- Dockerfile جاهز للنشر.

## ما يلزم منك للربط الفعلي
1. حساب Meta Business.
2. WhatsApp Business Platform/Cloud API.
3. Instagram Professional مرتبط بصفحة Facebook.
4. مفتاح OpenAI API.
5. استضافة HTTPS للـ Backend.

لا ترسل مفاتيحك السرية هنا. ضعها في متغيرات البيئة في الاستضافة.
