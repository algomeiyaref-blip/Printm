const API=localStorage.getItem("prinm0_api")||window.location.origin;
let TOKEN=localStorage.getItem("prinm0_admin_token")||"";
const demo=()=>localStorage.getItem("prinm0_demo")==="1";

async function api(path,opt={}){
  opt.headers={...(opt.headers||{}),"Content-Type":"application/json","Authorization":"Bearer "+TOKEN};
  const r=await fetch(API+path,opt);
  if(r.status===401){logout();throw Error("unauthorized")}
  if(!r.ok)throw Error("API "+r.status);
  return r.json();
}
async function login(){
  const err=document.getElementById("err"); err.textContent="جاري الاتصال بالخادم...";
  try{
    const r=await fetch(API+"/admin/login",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username:document.getElementById("u").value,password:document.getElementById("p").value})});
    if(!r.ok)throw Error("بيانات الدخول غير صحيحة");
    const d=await r.json(); TOKEN=d.token;
    localStorage.setItem("prinm0_admin_token",TOKEN); localStorage.removeItem("prinm0_demo"); showPanel();
  }catch(e){
    err.textContent="الخادم غير متصل. استخدم «تجربة بدون خادم» لاختبار الواجهة، أو شغّل Backend ثم أعد المحاولة.";
  }
}
function demoLogin(){localStorage.setItem("prinm0_demo","1");showPanel()}
function logout(){localStorage.removeItem("prinm0_admin_token");localStorage.removeItem("prinm0_demo");TOKEN="";
 document.getElementById("panel").style.display="none";document.getElementById("login").style.display="block"}
function showPanel(){document.getElementById("login").style.display="none";document.getElementById("panel").style.display="block";render("dashboard")}
function demoRows(kind){
 const sets={
 chats:[["محمد","أريد معرفة سعر المنتج"],["سارة","هل يوجد توصيل؟"]],
 customers:[["محمد","0500000000"],["سارة","0500000001"]],
 products:[["تيشيرت مخصص","3500 ريال · المخزون 20"],["كاب مطبوع","2000 ريال · المخزون 15"]],
 orders:[["#1008","10500 ريال · قيد المراجعة"],["#1007","6000 ريال · جديد"]]
 };
 return sets[kind]||[];
}
async function render(kind){
 const app=document.querySelector("#content");
 if(demo()){
  if(kind==="dashboard")app.innerHTML=`<div class="grid"><div class="stat">المحادثات<b>24</b></div><div class="stat">العملاء<b>13</b></div><div class="stat">المنتجات<b>6</b></div><div class="stat">الطلبات<b>8</b></div></div><div class="section"><div class="box"><h3>وضع التجربة</h3><p class="muted">الواجهة تعمل محلياً. الربط الحقيقي يحتاج Backend.</p></div></div>`;
  else {const map={chats:["المحادثات","💬"],customers:["العملاء","👤"],products:["المنتجات","📦"],orders:["الطلبات","🛒"]};let [title,icon]=map[kind];app.innerHTML=`<div class="section"><h2>${title}</h2><div class="list">${demoRows(kind).map(x=>`<div class="row"><div class="avatar">${icon}</div><div class="grow"><b>${x[0]}</b><div class="muted">${x[1]}</div></div></div>`).join("")}</div></div>`}
 } else {
  try{
   if(kind==="dashboard"){app.innerHTML=`<div class="grid"><div class="stat">المحادثات<b id="m">...</b></div><div class="stat">العملاء<b id="c">...</b></div><div class="stat">المنتجات<b id="pc">...</b></div><div class="stat">الطلبات<b id="oc">...</b></div></div>`;let [sum,cs,ps,os]=await Promise.all([api("/admin/summary"),api("/admin/customers"),api("/admin/products"),api("/admin/orders")]);m.textContent=sum.messages;c.textContent=cs.items.length;pc.textContent=ps.items.length;oc.textContent=os.items.length}
   if(kind==="chats"){let d=await api("/messages");app.innerHTML=`<div class=section><h2>المحادثات</h2><div class=list>${d.messages.map(x=>`<div class=row><div class=avatar>💬</div><div class=grow><b>${x.customer_id}</b><div class=muted>${x.text}</div></div></div>`).join("")}</div></div>`}
   if(kind==="customers"){let d=await api("/admin/customers");app.innerHTML=`<div class=section><h2>العملاء</h2><div class=list>${d.items.map(x=>`<div class=row><div class=avatar>👤</div><div class=grow><b>${x.name}</b><div class=muted>${x.phone||""}</div></div><button class=btn onclick="delCustomer(${x.id})">حذف</button></div>`).join("")}</div></div>`}
   if(kind==="products"){let d=await api("/admin/products");app.innerHTML=`<div class=section><h2>المنتجات</h2><div class=list>${d.items.map(x=>`<div class=row><div class=avatar>📦</div><div class=grow><b>${x.name}</b><div class=muted>${x.price} · ${x.stock}</div></div><button class=btn onclick="delProduct(${x.id})">حذف</button></div>`).join("")}</div></div>`}
   if(kind==="orders"){let d=await api("/admin/orders");app.innerHTML=`<div class=section><h2>الطلبات</h2><div class=list>${d.items.map(x=>`<div class=row><div class=avatar>🛒</div><div class=grow><b>#${x.id}</b><div class=muted>${x.total}</div></div></div>`).join("")}</div></div>`}
  }catch(e){app.innerHTML=`<div class=section><div class=box><h3>تعذر الاتصال بالخادم</h3><p class=muted>شغّل Backend واضبط عنوان API.</p></div></div>`}
 }
 document.querySelectorAll(".nav button").forEach(x=>x.classList.toggle("active",x.dataset.k===kind));
}
async function delCustomer(id){if(confirm("حذف العميل؟")){await api("/admin/customers/"+id,{method:"DELETE"});render("customers")}}
async function delProduct(id){if(confirm("حذف المنتج؟")){await api("/admin/products/"+id,{method:"DELETE"});render("products")}}
document.addEventListener("DOMContentLoaded",()=>{document.getElementById("apiLabel").textContent=API;if(demo()||TOKEN)showPanel();else logout()});
