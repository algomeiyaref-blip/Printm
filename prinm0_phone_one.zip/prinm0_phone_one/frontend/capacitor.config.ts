import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.prinm0.business',
  appName: 'prinm0',
  webDir: '.',
  server: { cleartext: false }
};
export default config;
